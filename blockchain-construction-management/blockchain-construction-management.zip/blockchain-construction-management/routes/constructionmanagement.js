var express = require('express');
var router = express.Router();

var historyInformation_controller = require('../controllers/historyInformationController');
var chart_controller = require('../controllers/chartController');
var create_controller = require('../controllers/createController');

// HISTORICAL INFORMATION ROUTES:

// Get home page.
router.get('/', historyInformation_controller.index);

//---Router for history information---//

// Get request for displaying list of all orders.
router.get('/history-information/order-list', historyInformation_controller.order_list);

// Get request for displaying list of all commercial managers.
router.get('/history-information/commercialmanager-list', historyInformation_controller.commercialManager_list);

// Get request for displaying list of all suppliers.
router.get('/history-information/supplier-list', historyInformation_controller.supplier_list);

// Get request for displaying list of all shippers.
router.get('/history-information/shipper-list', historyInformation_controller.shipper_list);

// Get request for displaying list of all site fore man.
router.get('/history-information/siteforeman-list', historyInformation_controller.siteForeMan_list);

// Get request for displaying list of all installers.
router.get('/history-information/installer-list', historyInformation_controller.installer_list);

// Get request for displaying list of all clerks of work.
router.get('/history-information/clerkofwork-list', historyInformation_controller.clerkOfWork_list);

// Get request for displaying list of all create order transactions.
router.get('/history-information/createorder-list', historyInformation_controller.createOrder_list);

// Get request for displaying list of all buy transactions.
router.get('/history-information/buy-list', historyInformation_controller.buy_list);

// Get request for displaying list of all buy transactions.
router.get('/history-information/reqestshipping-list', historyInformation_controller.requestShipping_list);

// Get request for displaying list of all delivering transactions.
router.get('/history-information/delivering-list', historyInformation_controller.delivering_list);

// Get request for displaying list of all deliver transactions.
router.get('/history-information/deliver-list', historyInformation_controller.deliver_list);

// Get request for displaying list of all deliver confirmation transactions.
router.get('/history-information/deliverconfirmation-list', historyInformation_controller.deliverConfirmation_list);

// Get request for displaying list of make payment transactions.
router.get('/history-information/makepayment-list', historyInformation_controller.makePayment_list);

// Get request for displaying list of all test passed transactions.
router.get('/history-information/testpassed-list', historyInformation_controller.testPassed_list);

// Get request for displaying list of all test failed transactions.
router.get('/history-information/testfailed-list', historyInformation_controller.testFailed_list);

// Get request for displaying list of all installed transactions.
router.get('/history-information/installed-list', historyInformation_controller.installed_list);

// Get request for displaying list of all not installed transactions.
router.get('/history-information/notinstalled-list', historyInformation_controller.notInstalled_list);

// Get request for displaying list of all test and install transactions.
router.get('/history-information/testandinstallconfirmation-list', historyInformation_controller.testAndInstallConfirmation_list);

// Get request for displaying list of all request refund transactions.
router.get('/history-information/requestrefund-list', historyInformation_controller.requestRefund_list);

// Get request for displaying list of all request shipping back order transactions.
router.get('/history-information/requestshippingbackorder-list', historyInformation_controller.requestShippingBackOrder_list);

// Get request for displaying list of all refund transactions.
router.get('/history-information/refund-list', historyInformation_controller.refund_list);

// Get request for displaying list of all completed order transactions.
router.get('/history-information/completedorder-list', historyInformation_controller.orderCompleted_list);

//---Router for create---//

// GET request for creating a Commercial Manager.
router.get('/create/commercial-manager', create_controller.commercial_create_get);

// POST request for creating a Commercial Manager.
router.post('/create/commercial-manager', create_controller.commercial_create_post);

// GET request for creating a Supplier.
router.get('/create/supplier', create_controller.supplier_create_get);

// POST request for creating a Supplier.
router.post('/create/supplier', create_controller.supplier_create_post);

// GET request for creating a Shipper.
router.get('/create/shipper', create_controller.shipper_create_get);

// POST request for creating a Shipper.
router.post('/create/shipper', create_controller.shipper_create_post);

// GET request for creating a SiteForeMan.
router.get('/create/siteforeman', create_controller.siteforeman_create_get);

// POST request for creating a SiteForeMan.
router.post('/create/siteforeman', create_controller.siteforeman_create_post);

// GET request for creating a Installer.
router.get('/create/installer', create_controller.installer_create_get);

// POST request for creating a Installer.
router.post('/create/installer', create_controller.installer_create_post);

// GET request for creating a clerk of work.
router.get('/create/clerk-of-work', create_controller.clerkOfWork_create_get);

// POST request for creating an a clerk of work.
router.post('/create/clerk-of-work', create_controller.clerkOfWork_create_post);

// GET request for creating an Order.
router.get('/create/order-transaction', create_controller.order_transaction_get);

// POST request for creating a Order.
router.post('/create/order-transaction', create_controller.order_transaction_post);

// GET request for creating a buy transaction.
router.get('/create/buy-transaction', create_controller.buy_transaction_get);

// POST request for creating a buy transaction.
router.post('/create/buy-transaction', create_controller.buy_transaction_post);

// GET request for creating a buy transaction.
router.get('/create/requestshipping-transaction', create_controller.requestshipping_transaction_get);

// POST request for creating a buy transaction.
router.post('/create/requestshipping-transaction', create_controller.requestshipping_transaction_post);

// GET request for creating a delivering transaction.
router.get('/create/delivering-transaction', create_controller.delivering_transaction_get);

// POST request for creating a delivering transaction.
router.post('/create/delivering-transaction', create_controller.delivering_transaction_post);

// GET request for creating a deliver transaction.
router.get('/create/deliver-transaction', create_controller.deliver_transaction_get);

// POST request for creating a deliver transaction.
router.post('/create/deliver-transaction', create_controller.deliver_transaction_post);

// GET request for creating a deliver confirmation transaction.
router.get('/create/deliver-confirmation-transaction', create_controller.deliver_confirmation_transaction_get);

// POST request for creating a deliver confirmation transaction.
router.post('/create/deliver-confirmation-transaction', create_controller.deliver_confirmation_transaction_post);

// GET request for creating a make payment transaction.
router.get('/create/make-payment-transaction', create_controller.make_payment_transaction_get);

// POST request for creating a make payment transaction.
router.post('/create/make-payment-transaction', create_controller.make_payment_transaction_post);

// GET request for creating a test passed transaction.
router.get('/create/testpassed-transaction', create_controller.testpassed_transaction_get);

// POST request for creating a test passed transaction.
router.post('/create/testpassed-transaction', create_controller.testpassed_transaction_post);

// GET request for creating a test failed transaction.
router.get('/create/testfailed-transaction', create_controller.testfailed_transaction_get);

// POST request for creating a test failed transaction.
router.post('/create/testfailed-transaction', create_controller.testfailed_transaction_post);

// GET request for creating a not installed transaction.
router.get('/create/notinstalled-transaction', create_controller.notinstalled_transaction_get);

// POST request for creating a not installed transaction.
router.post('/create/notinstalled-transaction', create_controller.notinstalled_transaction_post);

// GET request for creating a installed transaction.
router.get('/create/installed-transaction', create_controller.installed_transaction_get);

// POST request for creating a installed transaction.
router.post('/create/installed-transaction', create_controller.installed_transaction_post);

// GET request for creating a Test and Install Confirmation transaction.
router.get('/create/test-and-install-confirmation-transaction', create_controller.test_and_install_confirmation_transaction_get);

// POST request for creating a Test and Install Confirmation transaction.
router.post('/create/test-and-install-confirmation-transaction', create_controller.test_and_install_confirmation_transaction_post);

// GET request for creating a Request Refund transaction.
router.get('/create/request-refund-transaction', create_controller.request_refund_transaction_get);

// POST request for creating a Request Refund transaction.
router.post('/create/request-refund-transaction', create_controller.request_refund_transaction_post);

// GET request for creating a Request Shipping Back transaction.
router.get('/create/request-shipping-back-transaction', create_controller.request_shipping_back_transaction_get);

// POST request for creating a Request Shipping Back transaction.
router.post('/create/request-shipping-back-transaction', create_controller.request_shipping_back_transaction_post);

// GET request for creating a Refund transaction.
router.get('/create/refund-transaction', create_controller.refund_transaction_get);

// POST request for creating a Refund transaction.
router.post('/create/refund-transaction', create_controller.refund_transaction_post);

// GET request for creating a Refund transaction.
router.get('/create/ordercompleted-transaction', create_controller.order_completed_transaction_get);

// POST request for creating a Refund transaction.
router.post('/create/ordercompleted-transaction', create_controller.order_completed_transaction_post);

//---Router for charts---//

// Get request for displaying Gantt & pipe chart.
router.get('/chart/gantt-chart', chart_controller.progress_chart);

// Get request for displaying bar & pipe chart.
router.get('/chart/budget-chart', chart_controller.budget_chart);

module.exports = router;
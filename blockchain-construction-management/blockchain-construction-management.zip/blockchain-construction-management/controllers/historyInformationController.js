const request = require('request');

// Display home page.
exports.index = function(req,res) {
    res.render('index',{title: 'Construction Management Blockchain'});
};

// Display list of all orders.
exports.order_list = function(req, res) {
    //res.send('NOT IMPLEMENTED: Order list');
    request('http://localhost:3000/api/Order', function (error, response, body) {
        if (error) {
            console.log('error:', error); // Print the error if one occurred
            console.log('statusCode:', response && response.statusCode); // Print the response status code if a response was received
            console.log('body:', body); // Print the HTML for the Google homepage.
            return next(error);
        }
        res.render('order_list', {title:'Order List', order_list: body});
      });
};

// Display list of all commercial managers.
exports.commercialManager_list = function(req, res) {
    // res.send('NOT IMPLEMENTED: Commercial Manager list');
    request('http://localhost:3000/api/CommercialManager', function (error, response, body) {
        if (error) {
            console.log('error:', error); // Print the error if one occurred
            console.log('statusCode:', response && response.statusCode); // Print the response status code if a response was received
            console.log('body:', body); // Print the HTML for the Google homepage.
            return next(error);
        }
        res.render('commercial_list', {title:'Commercial Manager List', commercialmanager_list: body});
      });
};

// Display list of suppliers.
exports.supplier_list = function(req, res) {
    // res.send('NOT IMPLEMENTED: Supplier list');
    request('http://localhost:3000/api/Supplier', function (error, response, body) {
        if (error) {
            console.log('error:', error); // Print the error if one occurred
            console.log('statusCode:', response && response.statusCode); // Print the response status code if a response was received
            console.log('body:', body); // Print the HTML for the Google homepage.
            return next(error);
        }
        res.render('supplier_list', {title:'Supplier List', supplier_list: body});
      });    
};

// Display list of all shippers.
exports.shipper_list = function(req, res) {
    // res.send('NOT IMPLEMENTED: Order list');
    request('http://localhost:3000/api/Shipper', function (error, response, body) {
        if (error) {
            console.log('error:', error); // Print the error if one occurred
            console.log('statusCode:', response && response.statusCode); // Print the response status code if a response was received
            console.log('body:', body); // Print the HTML for the Google homepage.
            return next(error);
        }
        res.render('shipper_list', {title:'Shipper List', shipper_list: body});
      });    
};

// Display list of site fore man.
exports.siteForeMan_list = function(req, res) {
    // res.send('NOT IMPLEMENTED: Site Fore Man list');
    request('http://localhost:3000/api/SiteForeMan', function (error, response, body) {
        if (error) {
            console.log('error:', error); // Print the error if one occurred
            console.log('statusCode:', response && response.statusCode); // Print the response status code if a response was received
            console.log('body:', body); // Print the HTML for the Google homepage.
            return next(error);
        }
        res.render('siteforeman_list', {title:'Site Fore Man List', siteforeman_list: body});
      }); 
};

// Display list of installers.
exports.installer_list = function(req, res) {
    // res.send('NOT IMPLEMENTED: Installer list');
    request('http://localhost:3000/api/Installer', function (error, response, body) {
        if (error) {
            console.log('error:', error); // Print the error if one occurred
            console.log('statusCode:', response && response.statusCode); // Print the response status code if a response was received
            console.log('body:', body); // Print the HTML for the Google homepage.
            return next(error);
        }
        res.render('installer_list', {title:'Installer List', installer_list: body});
      }); 
};

// Display list of all clerks of work.
exports.clerkOfWork_list = function(req, res) {
    // res.send('NOT IMPLEMENTED: Clerk Of Work list');
    request('http://localhost:3000/api/ClerkOfWork', function (error, response, body) {
        if (error) {
            console.log('error:', error); // Print the error if one occurred
            console.log('statusCode:', response && response.statusCode); // Print the response status code if a response was received
            console.log('body:', body); // Print the HTML for the Google homepage.
            return next(error);
        }
        res.render('clerkofwork_list', {title:'Clerk Of Work List', clerkofwork_list: body});
      }); 
};

// Display list of all create order transactions.
exports.createOrder_list = function(req, res) {
    // res.send('NOT IMPLEMENTED: Create Order list');
    request('http://localhost:3000/api/CreateOrder', function (error, response, body) {
        if (error) {
            console.log('error:', error); // Print the error if one occurred
            console.log('statusCode:', response && response.statusCode); // Print the response status code if a response was received
            console.log('body:', body); // Print the HTML for the Google homepage.
            return next(error);
        }
        res.render('createorder_list', {title:'Created Order List', createorder_list: body});
      }); 
};

// Display list of all buy transactions.
exports.buy_list = function(req, res) {
    // res.send('NOT IMPLEMENTED: Buy list');
    request('http://localhost:3000/api/Buy', function (error, response, body) {
        if (error) {
            console.log('error:', error); // Print the error if one occurred
            console.log('statusCode:', response && response.statusCode); // Print the response status code if a response was received
            console.log('body:', body); // Print the HTML for the Google homepage.
            return next(error);
        }
        res.render('buy_list', {title:'Buy List', buy_list: body});
      }); 
};

// Display list of all request shipping transactions.
exports.requestShipping_list = function(req, res) {
    // res.send('NOT IMPLEMENTED: Request Shipping list');
    request('http://localhost:3000/api/RequestShipping', function (error, response, body) {
        if (error) {
            console.log('error:', error); // Print the error if one occurred
            console.log('statusCode:', response && response.statusCode); // Print the response status code if a response was received
            console.log('body:', body); // Print the HTML for the Google homepage.
            return next(error);
        }
        res.render('requestshipping_list', {title:'Request Shipping List', requestshipping_list: body});
      });
};

// Display list of all delivering transactions.
exports.delivering_list = function(req, res) {
    // res.send('NOT IMPLEMENTED: Delivering list');
    request('http://localhost:3000/api/Delivering', function (error, response, body) {
        if (error) {
            console.log('error:', error); // Print the error if one occurred
            console.log('statusCode:', response && response.statusCode); // Print the response status code if a response was received
            console.log('body:', body); // Print the HTML for the Google homepage.
            return next(error);
        }
        res.render('delivering_list', {title:'Delivering List', delivering_list: body});
      });    
};

// Display list of all deliver transactions.
exports.deliver_list = function(req, res) {
    // res.send('NOT IMPLEMENTED: Deliver list');
    request('http://localhost:3000/api/Deliver', function (error, response, body) {
        if (error) {
            console.log('error:', error); // Print the error if one occurred
            console.log('statusCode:', response && response.statusCode); // Print the response status code if a response was received
            console.log('body:', body); // Print the HTML for the Google homepage.
            return next(error);
        }
        res.render('deliver_list', {title:'Deliver Shipping List', deliver_list: body});
      }); 
};

// Display list of all deliver confirmation transactions.
exports.deliverConfirmation_list = function(req, res) {
    // res.send('NOT IMPLEMENTED: Deliver Confirmation list');
    request('http://localhost:3000/api/DeliverConfirmation', function (error, response, body) {
        if (error) {
            console.log('error:', error); // Print the error if one occurred
            console.log('statusCode:', response && response.statusCode); // Print the response status code if a response was received
            console.log('body:', body); // Print the HTML for the Google homepage.
            return next(error);
        }
        res.render('deliverconfirmation_list', {title:'Deliver Confirmation List', deliverconfirmation_list: body});
      }); 
};

// Display list of all make payment transactions.
exports.makePayment_list = function(req, res) {
    // res.send('NOT IMPLEMENTED: Make payment list');
    request('http://localhost:3000/api/MakePayment', function (error, response, body) {
        if (error) {
            console.log('error:', error); // Print the error if one occurred
            console.log('statusCode:', response && response.statusCode); // Print the response status code if a response was received
            console.log('body:', body); // Print the HTML for the Google homepage.
            return next(error);
        }
        res.render('makepayment_list', {title:'Make Payment List', makepayment_list: body});
      }); 
};

// Display list of all test passed transactions.
exports.testPassed_list = function(req, res) {
    // res.send('NOT IMPLEMENTED: Test passed list');
    request('http://localhost:3000/api/TestPassed', function (error, response, body) {
        if (error) {
            console.log('error:', error); // Print the error if one occurred
            console.log('statusCode:', response && response.statusCode); // Print the response status code if a response was received
            console.log('body:', body); // Print the HTML for the Google homepage.
            return next(error);
        }
        res.render('testpassed_list', {title:'Test Passed List', testpassed_list: body});
      }); 
};

// Display list of all test failed transactions.
exports.testFailed_list = function(req, res) {
    // res.send('NOT IMPLEMENTED: Test failed list');
    request('http://localhost:3000/api/TestFailed', function (error, response, body) {
        if (error) {
            console.log('error:', error); // Print the error if one occurred
            console.log('statusCode:', response && response.statusCode); // Print the response status code if a response was received
            console.log('body:', body); // Print the HTML for the Google homepage.
            return next(error);
        }
        res.render('testfailed_list', {title:'Test Failed List', testfailed_list: body});
      }); 
};

// Display list of all installed transactions.
exports.installed_list = function(req, res) {
    // res.send('NOT IMPLEMENTED: Installed list');
    request('http://localhost:3000/api/Installed', function (error, response, body) {
        if (error) {
            console.log('error:', error); // Print the error if one occurred
            console.log('statusCode:', response && response.statusCode); // Print the response status code if a response was received
            console.log('body:', body); // Print the HTML for the Google homepage.
            return next(error);
        }
        res.render('installed_list', {title:'Installed List', installed_list: body});
      }); 
};

// Display list of all not installed transactions.
exports.notInstalled_list = function(req, res) {
    // res.send('NOT IMPLEMENTED: Not installed list');
    request('http://localhost:3000/api/NotInstalled', function (error, response, body) {
        if (error) {
            console.log('error:', error); // Print the error if one occurred
            console.log('statusCode:', response && response.statusCode); // Print the response status code if a response was received
            console.log('body:', body); // Print the HTML for the Google homepage.
            return next(error);
        }
        res.render('notinstalled_list', {title:'Not Installed List', notinstalled_list: body});
      });     
};

// Display list of all test and install transactions.
exports.testAndInstallConfirmation_list = function(req, res) {
    // res.send('NOT IMPLEMENTED: Test And Install list');
    request('http://localhost:3000/api/TestAndInstallationConfirmation', function (error, response, body) {
        if (error) {
            console.log('error:', error); // Print the error if one occurred
            console.log('statusCode:', response && response.statusCode); // Print the response status code if a response was received
            console.log('body:', body); // Print the HTML for the Google homepage.
            return next(error);
        }
        res.render('testandinstall_list', {title:'Test and Install Confirmation List', testandinstall_list: body});
      }); 
};

// Display list of all request refund transactions.
exports.requestRefund_list = function(req, res) {
    // res.send('NOT IMPLEMENTED: Request refund list');
    request('http://localhost:3000/api/RequestRefund', function (error, response, body) {
        if (error) {
            console.log('error:', error); // Print the error if one occurred
            console.log('statusCode:', response && response.statusCode); // Print the response status code if a response was received
            console.log('body:', body); // Print the HTML for the Google homepage.
            return next(error);
        }
        res.render('requestrefund_list', {title:'Request Refund List', requestrefund_list: body});
      }); 
};

// Display list of all request shipping back order transactions.
exports.requestShippingBackOrder_list = function(req, res) {
    // res.send('NOT IMPLEMENTED: Request shipping back order list');
    request('http://localhost:3000/api/RequestShippingBackOrder', function (error, response, body) {
        if (error) {
            console.log('error:', error); // Print the error if one occurred
            console.log('statusCode:', response && response.statusCode); // Print the response status code if a response was received
            console.log('body:', body); // Print the HTML for the Google homepage.
            return next(error);
        }
        res.render('requestshippingbackorder_list', {title:'Request Shipping Back Order List', requestshippingbackorder_list: body});
      }); 
};

// Display list of all refund transactions.
exports.refund_list = function(req, res) {
    // res.send('NOT IMPLEMENTED: Refund list');
    request('http://localhost:3000/api/Refund', function (error, response, body) {
        if (error) {
            console.log('error:', error); // Print the error if one occurred
            console.log('statusCode:', response && response.statusCode); // Print the response status code if a response was received
            console.log('body:', body); // Print the HTML for the Google homepage.
            return next(error);
        }
        res.render('refund_list', {title:'Refund List', refund_list: body});
      }); 
};

// Display list of all order completed transactions.
exports.orderCompleted_list = function(req, res) {
    // res.send('NOT IMPLEMENTED: Order completed list');
    request('http://localhost:3000/api/OrderCompleted', function (error, response, body) {
        if (error) {
            console.log('error:', error); // Print the error if one occurred
            console.log('statusCode:', response && response.statusCode); // Print the response status code if a response was received
            console.log('body:', body); // Print the HTML for the Google homepage.
            return next(error);
        }
        res.render('ordercompleted_list', {title:'Completed Order List', ordercompleted_list: body});
      }); 
};

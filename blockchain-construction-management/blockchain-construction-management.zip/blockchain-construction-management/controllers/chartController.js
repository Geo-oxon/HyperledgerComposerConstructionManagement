const request = require('request');

// Display progress management.
exports.progress_chart = function(req, res) {
    //res.send('NOT IMPLEMENTED: Order list');
    request('http://localhost:3000/api/Order', function (error, response, body) {
        if (error) {
            console.log('error:', error); // Print the error if one occurred
            console.log('statusCode:', response && response.statusCode); // Print the response status code if a response was received
            console.log('body:', body); // Print the HTML for the Google homepage.
            return next(error);
        }
        res.render('gantt_chart', {title:'Gantt Chart', order_list: body});
      });
};

// Display budget management.
exports.budget_chart = function(req, res) {
    // res.send('NOT IMPLEMENTED: Budget management');
    request('http://localhost:3000/api/Order', function (error, response, body) {
        if (error) {
            console.log('error:', error); // Print the error if one occurred
            console.log('statusCode:', response && response.statusCode); // Print the response status code if a response was received
            console.log('body:', body); // Print the HTML for the Google homepage.
            return next(error);
        }
        res.render('budget_chart', {title:'Budget Chart', order_list: body});
      });
};
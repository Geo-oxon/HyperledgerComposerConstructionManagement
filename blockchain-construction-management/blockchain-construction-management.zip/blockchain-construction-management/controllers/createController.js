const validator = require('express-validator');
const request = require('request');

// Display Commercial Manager create form on GET.
exports.commercial_create_get = function(req, res, next) {     
  res.render('createcommercialmanager_form', { title: 'Create Commercial Manager' });
};


// Handle Commercial Manager create on POST.
exports.commercial_create_post =  [
	
	// Validate that the commercialmanagerID field is not empty.
 	 validator.body('commercialmanagerID', 'Commercial ID required').isLength({ min: 1 }).trim(),
	// Validate that the company field is not empty.
 	 validator.body('company', 'Company ID required').isLength({ min: 1 }).trim(),

  	// Sanitize (escape) the commercialmanagerID field.
  	validator.sanitizeBody('commercialmanagerID').escape(),
  	// Sanitize (escape) the commercialmanagerID field.
  	validator.sanitizeBody('company').escape(),

  	// Process request after validation and sanitization.
  	(req, res, next) => {
	  	// Extract the validation errors from a request.
	    const errors = validator.validationResult(req);

	    // Create a genre object with escaped and trimmed data.
		var options = {
		  	uri: 'http://localhost:3000/api/CommercialManager',
		  	method: 'POST',
		  	json:{
				"$class": "org.example.basic.CommercialManager",
			  	"commercialManagerID": req.body.commercialmanagerID,
			  	"companyName": req.body.company
			}
		};

	    if (!errors.isEmpty()) {
	    	// There are errors. Render the form again with sanitized values/error messages.
	      	res.render('createcommercialmanager_form', { title: 'Create Commercial Manager', 
	      		errors: errors.array()});
	      	return;
	    } else {
	    	console.log("Success");
	    	request(options, function (error, response, body) {
			  if (!error && response.statusCode == 200) {
			    console.log(body) // Print the shortened url.
			    res.render('createcommercialmanager_form', { title: 'Create Commercial Manager',
			    	mess: 'Success!'});
			  } else {
			  	console.log(body['error']['message']);
	      		res.render('createcommercialmanager_form', { title: 'Create Commercial Manager', 
	      		mess: body['error']['message']});			  	
			  }
			});
	    }
	}
];

// Display Supplier create form on GET.
exports.supplier_create_get = function(req, res, next) {     
  res.render('createsupplier_form', { title: 'Create Supplier' });
};

// Handle Supplier create on POST.
exports.supplier_create_post =  [
	
	// Validate that the supplierID field is not empty.
 	 validator.body('supplierID', 'Supplier ID required').isLength({ min: 1 }).trim(),
	// Validate that the company field is not empty.
 	 validator.body('company', 'Company ID required').isLength({ min: 1 }).trim(),

  	// Sanitize (escape) the supplierID field.
  	validator.sanitizeBody('supplierID').escape(),
  	// Sanitize (escape) the supplierID field.
  	validator.sanitizeBody('company').escape(),

  	// Process request after validation and sanitization.
  	(req, res, next) => {
	  	// Extract the validation errors from a request.
	    const errors = validator.validationResult(req);

	    // Create a genre object with escaped and trimmed data.
		var options = {
		  	uri: 'http://localhost:3000/api/Supplier',
		  	method: 'POST',
		  	json:{
				"$class": "org.example.basic.Supplier",
			  	"supplierID": req.body.supplierID,
			  	"companyName": req.body.company
			}
		};

	    if (!errors.isEmpty()) {
	    	// There are errors. Render the form again with sanitized values/error messages.
	      	res.render('createsupplier_form', { title: 'Create Supplier', 
	      		errors: errors.array()});
	      	return;
	    } else {
	    	console.log("Success");
	    	console.log(req.body.supplierID);
	    	request(options, function (error, response, body) {
			  if (!error && response.statusCode == 200) {
			    console.log(body) // Print the shortened url.
			    res.render('createsupplier_form', { title: 'Create Supplier Manager',
			    	mess: 'Success!'});
			  } else {
			  	console.log(body['error']['message']);
	      		res.render('createsupplier_form', { title: 'Create Supplier Manager', 
	      		mess: body['error']['message']});			  	
			  }
			});
	    }
	}
];

// Display Shipper create form on GET.
exports.shipper_create_get = function(req, res, next) {     
  res.render('createshipper_form', { title: 'Create Shipper' });
};

// Handle Shipper create on POST.
exports.shipper_create_post =  [
	
	// Validate that the shipperID field is not empty.
 	 validator.body('shipperID', 'Shipper ID required').isLength({ min: 1 }).trim(),
	// Validate that the company field is not empty.
 	 validator.body('company', 'Company ID required').isLength({ min: 1 }).trim(),

  	// Sanitize (escape) the shipperID field.
  	validator.sanitizeBody('shipperID').escape(),
  	// Sanitize (escape) the supplierID field.
  	validator.sanitizeBody('company').escape(),

  	// Process request after validation and sanitization.
  	(req, res, next) => {
	  	// Extract the validation errors from a request.
	    const errors = validator.validationResult(req);

	    // Create a genre object with escaped and trimmed data.
		var options = {
		  	uri: 'http://localhost:3000/api/Shipper',
		  	method: 'POST',
		  	json:{
				"$class": "org.example.basic.Shipper",
			  	"shipperID": req.body.shipperID,
			  	"companyName": req.body.company
			}
		};

	    if (!errors.isEmpty()) {
	    	// There are errors. Render the form again with sanitized values/error messages.
	    	console.log("Error");
	    	console.log(errors);
	      	res.render('createshipper_form', { title: 'Create Shipper', 
	      		errors: errors.array()});
	      	return;
	    } else {
	    	console.log("Success");
	    	request(options, function (error, response, body) {
			  if (!error && response.statusCode == 200) {
			    console.log(body) // Print the shortened url.
			    res.render('createshipper_form', { title: 'Create Shipper',
			    	mess: 'Success!'});
			  } else {
			  	console.log(body['error']['message']);
	      		res.render('createshipper_form', { title: 'Create Shipper', 
	      		mess: body['error']['message']});			  	
			  }
			});
	    }
	}
];

// Display Site Fore Man create form on GET.
exports.siteforeman_create_get = function(req, res, next) {     
  res.render('createsiteforeman_form', { title: 'Create Site Fore Man' });
};

// Handle Site Fore Man create on POST.
exports.siteforeman_create_post =  [
	
	// Validate that the siteForeManID field is not empty.
 	 validator.body('siteForeManID', 'Site Fore Man ID required').isLength({ min: 1 }).trim(),
	// Validate that the company field is not empty.
 	 validator.body('company', 'Company ID required').isLength({ min: 1 }).trim(),

  	// Sanitize (escape) the siteForeManID field.
  	validator.sanitizeBody('siteForeManID').escape(),
  	// Sanitize (escape) the company field.
  	validator.sanitizeBody('company').escape(),

  	// Process request after validation and sanitization.
  	(req, res, next) => {
	  	// Extract the validation errors from a request.
	    const errors = validator.validationResult(req);

	    // Create a genre object with escaped and trimmed data.
		var options = {
		  	uri: 'http://localhost:3000/api/SiteForeMan',
		  	method: 'POST',
		  	json:{
				"$class": "org.example.basic.SiteForeMan",
			  	"siteForeManID": req.body.siteForeManID,
			  	"companyName": req.body.company
			}
		};

	    if (!errors.isEmpty()) {
	    	// There are errors. Render the form again with sanitized values/error messages.
	    	console.log("Error");
	    	console.log(errors);
	      	res.render('createshipper_form', { title: 'Create Site Fore Man', 
	      		errors: errors.array()});
	      	return;
	    } else {
	    	console.log("Success");
	    	request(options, function (error, response, body) {
			  if (!error && response.statusCode == 200) {
			    console.log(body) // Print the shortened url.
			    res.render('createsiteforeman_form', { title: 'Create Site Fore Man',
			    	mess: 'Success!'});
			  } else {
			  	console.log(body['error']['message']);
	      		res.render('createsiteforeman_form', { title: 'Create Site Fore Man', 
	      		mess: body['error']['message']});			  	
			  }
			});
	    }
	}
];

// Display Installer create form on GET.
exports.installer_create_get = function(req, res, next) {     
  res.render('createinstaller_form', { title: 'Create Installer' });
};

// Handle Installer create on POST.
exports.installer_create_post =  [
	
	// Validate that the installerID field is not empty.
 	 validator.body('installerID', 'Installer ID required').isLength({ min: 1 }).trim(),
	// Validate that the company field is not empty.
 	 validator.body('company', 'Company ID required').isLength({ min: 1 }).trim(),

  	// Sanitize (escape) the installerID field.
  	validator.sanitizeBody('installerID').escape(),
  	// Sanitize (escape) the company field.
  	validator.sanitizeBody('company').escape(),

  	// Process request after validation and sanitization.
  	(req, res, next) => {
	  	// Extract the validation errors from a request.
	    const errors = validator.validationResult(req);

	    // Create a genre object with escaped and trimmed data.
		var options = {
		  	uri: 'http://localhost:3000/api/Installer',
		  	method: 'POST',
		  	json:{
				"$class": "org.example.basic.Installer",
			  	"installerID": req.body.installerID,
			  	"companyName": req.body.company
			}
		};

	    if (!errors.isEmpty()) {
	    	// There are errors. Render the form again with sanitized values/error messages.
	    	console.log("Error");
	    	console.log(errors);
	      	res.render('createshipper_form', { title: 'Create Installer', 
	      		errors: errors.array()});
	      	return;
	    } else {
	    	console.log("Success");
	    	request(options, function (error, response, body) {
			  if (!error && response.statusCode == 200) {
			    console.log(body) // Print the shortened url.
			    res.render('createinstaller_form', { title: 'Create Installer',
			    	mess: 'Success!'});
			  } else {
			  	console.log(body['error']['message']);
	      		res.render('createinstaller_form', { title: 'Create Installer', 
	      		mess: body['error']['message']});			  	
			  }
			});
	    }
	}
];

// Display Clerk of Work create form on GET.
exports.clerkOfWork_create_get = function(req, res, next) {     
  res.render('createclerkOfWork_form', { title: 'Create Clerk Of Work' });
};

// Handle Clerk of Work create on POST.
exports.clerkOfWork_create_post =  [
	
	// Validate that the clerkOfWorkID field is not empty.
 	 validator.body('clerkOfWorkID', 'Clerk Of Work ID required').isLength({ min: 1 }).trim(),
	// Validate that the company field is not empty.
 	 validator.body('company', 'Company ID required').isLength({ min: 1 }).trim(),

  	// Sanitize (escape) the clerkOfWorkID field.
  	validator.sanitizeBody('clerkOfWorkID').escape(),
  	// Sanitize (escape) the company field.
  	validator.sanitizeBody('company').escape(),

  	// Process request after validation and sanitization.
  	(req, res, next) => {
	  	// Extract the validation errors from a request.
	    const errors = validator.validationResult(req);

	    // Create a genre object with escaped and trimmed data.
		var options = {
		  	uri: 'http://localhost:3000/api/ClerkOfWork',
		  	method: 'POST',
		  	json:{
				"$class": "org.example.basic.ClerkOfWork",
			  	"clerkOfWorkID": req.body.clerkOfWorkID,
			  	"companyName": req.body.company
			}
		};

	    if (!errors.isEmpty()) {
	    	// There are errors. Render the form again with sanitized values/error messages.
	    	console.log("Error");
	    	console.log(errors);
	      	res.render('createshipper_form', { title: 'Create Clerk Of Work', 
	      		errors: errors.array()});
	      	return;
	    } else {
	    	console.log("Success");
	    	request(options, function (error, response, body) {
			  if (!error && response.statusCode == 200) {
			    console.log(body) // Print the shortened url.
			    res.render('createclerkOfWork_form', { title: 'Create Clerk Of Work',
			    	mess: 'Success!'});
			  } else {
			  	console.log(body['error']['message']);
	      		res.render('createclerkOfWork_form', { title: 'Create Clerk Of Work', 
	      		mess: body['error']['message']});			  	
			  }
			});
	    }
	}
];

// Display Order create form on GET.
exports.order_transaction_get = function(req, res, next) {     
  res.render('ordertransaction_form', { title: 'Create an Order' });
};

// Handle Order create on POST.
exports.order_transaction_post =  [
	
	// Validate that the commercialManager field is not empty.
 	 validator.body('commercialManager', 'Commercial Manager ID required').isLength({ min: 1 }).trim(),
	
	// Validate that the commercialManager field is not empty.
 	 validator.body('supplier', 'Supplier ID required').isLength({ min: 1 }).trim(),
	
	// Validate that the company field is not empty.
 	 validator.body('order', 'Order Number required').isLength({ min: 1 }).trim(),

  	// Sanitize (escape) the commercialManager field.
  	validator.sanitizeBody('commercialManager').escape(),

  	// Sanitize (escape) the supplier field.
  	validator.sanitizeBody('supplier').escape(),

  	// Sanitize (escape) the order field.
  	validator.sanitizeBody('order').escape(),

  	// Process request after validation and sanitization.
  	(req, res, next) => {
	  	// Extract the validation errors from a request.
	    const errors = validator.validationResult(req);

	    // Create a genre object with escaped and trimmed data.
		var options = {
		  	uri: 'http://localhost:3000/api/CreateOrder',
		  	method: 'POST',
		  	json:{
				"$class": "org.example.basic.CreateOrder",
				"amount": 0,
			  	"commercialManager": req.body.commercialManager,
			  	"supplier": req.body.supplier,
			  	"order": req.body.order
			}
		};

	    if (!errors.isEmpty()) {
	    	// There are errors. Render the form again with sanitized values/error messages.
	    	console.log("Error");
	    	console.log(errors);
	      	res.render('ordertransaction_form', { title: 'Create an Order', 
	      		errors: errors.array()});
	      	return;
	    } else {
	    	console.log("Success");
	    	request(options, function (error, response, body) {
			  if (!error && response.statusCode == 200) {
			    console.log(body) // Print the shortened url.
			    res.render('ordertransaction_form', { title: 'Create an Order',
			    	mess: 'Success!'});
			  } else {
			  	console.log(body['error']['message']);
	      		res.render('ordertransaction_form', { title: 'Create an Order', 
	      		mess: body['error']['message']});			  	
			  }
			});
	    }
	}
];

// Display Buy create form on GET.
exports.buy_transaction_get = function(req, res, next) {     
  res.render('buytransaction_form', { title: 'Create a Buy Transaction' });
};

// Handle Buy create on POST.
exports.buy_transaction_post =  [
	
	// Validate that the commercialManager field is not empty.
 	 validator.body('commercialManager', 'Commercial Manager ID required').isLength({ min: 1 }).trim(),
	
	// Validate that the commercialManager field is not empty.
 	 validator.body('supplier', 'Supplier ID required').isLength({ min: 1 }).trim(),
	
	// Validate that the company field is not empty.
 	 validator.body('order', 'Order Number required').isLength({ min: 1 }).trim(),

  	// Sanitize (escape) the commercialManager field.
  	validator.sanitizeBody('commercialManager').escape(),

  	// Sanitize (escape) the supplier field.
  	validator.sanitizeBody('supplier').escape(),

  	// Sanitize (escape) the order field.
  	validator.sanitizeBody('order').escape(),

  	// Process request after validation and sanitization.
  	(req, res, next) => {
	  	// Extract the validation errors from a request.
	    const errors = validator.validationResult(req);

	    // Create a genre object with escaped and trimmed data.
		var options = {
		  	uri: 'http://localhost:3000/api/Buy',
		  	method: 'POST',
		  	json:{
				"$class": "org.example.basic.Buy",
			  	"order": req.body.order,	
			  	"supplier": req.body.supplier,			  			
			  	"commercialManager": req.body.commercialManager
			}
		};

	    if (!errors.isEmpty()) {
	    	// There are errors. Render the form again with sanitized values/error messages.
	    	console.log("Error");
	    	console.log(errors);
	      	res.render('buytransaction_form', { title: 'Create a Buy Transaction', 
	      		errors: errors.array()});
	      	return;
	    } else {
	    	console.log("Success");
	    	request(options, function (error, response, body) {
			  if (!error && response.statusCode == 200) {
			    console.log(body) // Print the shortened url.
			    res.render('buytransaction_form', { title: 'Create a Buy Transaction',
			    	mess: 'Success!'});
			  } else {
			  	console.log(body['error']['message']);
	      		res.render('buytransaction_form', { title: 'Create a Buy Transaction', 
	      		mess: body['error']['message']});			  	
			  }
			});
	    }
	}
];

// Display Buy create form on GET.
exports.requestshipping_transaction_get = function(req, res, next) {     
  res.render('requestshippingtransaction_form', { title: 'Create a Request Shipping Transaction' });
};

// Handle Buy create on POST.
exports.requestshipping_transaction_post =  [
	
	// Validate that the siteForeMan field is not empty.
 	 validator.body('siteForeMan', 'Site Fore Man ID required').isLength({ min: 1 }).trim(),

	// Validate that the ShippingCompanyName field is not empty.
 	 validator.body('ShippingCompanyName', 'ShippingCompanyName required').isLength({ min: 1 }).trim(),
	
	// Validate that the supplier field is not empty.
 	 validator.body('supplier', 'Supplier ID required').isLength({ min: 1 }).trim(),
	
	// Validate that the order field is not empty.
 	 validator.body('order', 'Order Number required').isLength({ min: 1 }).trim(),

  	// Sanitize (escape) the siteForeMan field.
  	validator.sanitizeBody('siteForeMan').escape(),

  	// Sanitize (escape) the siteForeMan field.
  	validator.sanitizeBody('ShippingCompanyName').escape(),

  	// Sanitize (escape) the supplier field.
  	validator.sanitizeBody('supplier').escape(),

  	// Sanitize (escape) the order field.
  	validator.sanitizeBody('order').escape(),

  	// Process request after validation and sanitization.
  	(req, res, next) => {
	  	// Extract the validation errors from a request.
	    const errors = validator.validationResult(req);

	    // Create a genre object with escaped and trimmed data.
		var options = {
		  	uri: 'http://localhost:3000/api/RequestShipping',
		  	method: 'POST',
		  	json:{
				"$class": "org.example.basic.RequestShipping",
  				"ShippingCompanyName": req.body.ShippingCompanyName,				
			  	"order": req.body.order,	
			  	"supplier": req.body.supplier,			  			
			  	"siteForeMan": req.body.siteForeMan
			}
		};

	    if (!errors.isEmpty()) {
	    	// There are errors. Render the form again with sanitized values/error messages.
	    	console.log("Error");
	    	console.log(errors);
	      	res.render('requestshippingtransaction_form', { title: 'Create a Request Shipping Transaction', 
	      		errors: errors.array()});
	      	return;
	    } else {
	    	console.log("Success");
	    	request(options, function (error, response, body) {
			  if (!error && response.statusCode == 200) {
			    console.log(body) // Print the shortened url.
			    res.render('requestshippingtransaction_form', { title: 'Create a Request Shipping Transaction',
			    	mess: 'Success!'});
			  } else {
			  	console.log(body['error']['message']);
	      		res.render('requestshippingtransaction_form', { title: 'Create a Request Shipping Transaction', 
	      		mess: body['error']['message']});			  	
			  }
			});
	    }
	}
];

// Display Delivering create form on GET.
exports.delivering_transaction_get = function(req, res, next) {     
  res.render('deliveringtransaction_form', { title: 'Create a Delivering Transaction' });
};

// Handle Delivering create on POST.
exports.delivering_transaction_post =  [
		
	// Validate that the shipper field is not empty.
 	 validator.body('shipper', 'Shipper ID required').isLength({ min: 1 }).trim(),
	
	// Validate that the order field is not empty.
 	 validator.body('order', 'Order Number required').isLength({ min: 1 }).trim(),

  	// Sanitize (escape) the shipper field.
  	validator.sanitizeBody('shipper').escape(),

  	// Sanitize (escape) the order field.
  	validator.sanitizeBody('order').escape(),

  	// Process request after validation and sanitization.
  	(req, res, next) => {
	  	// Extract the validation errors from a request.
	    const errors = validator.validationResult(req);

	    // Create a genre object with escaped and trimmed data.
		var options = {
		  	uri: 'http://localhost:3000/api/Delivering',
		  	method: 'POST',
		  	json:{
				"$class": "org.example.basic.Delivering",				
			  	"order": req.body.order,	
			  	"shipper": req.body.shipper
			}
		};

	    if (!errors.isEmpty()) {
	    	// There are errors. Render the form again with sanitized values/error messages.
	    	console.log("Error");
	    	console.log(errors);
	      	res.render('deliveringtransaction_form', { title: 'Create a Delivering Transaction', 
	      		errors: errors.array()});
	      	return;
	    } else {
	    	console.log("Success");
	    	request(options, function (error, response, body) {
			  if (!error && response.statusCode == 200) {
			    console.log(body) // Print the shortened url.
			    res.render('deliveringtransaction_form', { title: 'Create a Delivering Transaction',
			    	mess: 'Success!'});
			  } else {
			  	console.log(body['error']['message']);
	      		res.render('deliveringtransaction_form', { title: 'Create a Delivering Transaction', 
	      		mess: body['error']['message']});			  	
			  }
			});
	    }
	}
];

// Display Deliver create form on GET.
exports.deliver_transaction_get = function(req, res, next) {     
  res.render('delivertransaction_form', { title: 'Create a Deliver Transaction' });
};

// Handle Deliver create on POST.
exports.deliver_transaction_post =  [
		
	// Validate that the shipper field is not empty.
 	 validator.body('shipper', 'Shipper ID required').isLength({ min: 1 }).trim(),
	
	// Validate that the order field is not empty.
 	 validator.body('order', 'Order Number required').isLength({ min: 1 }).trim(),

  	// Sanitize (escape) the shipper field.
  	validator.sanitizeBody('shipper').escape(),

  	// Sanitize (escape) the order field.
  	validator.sanitizeBody('order').escape(),

  	// Process request after validation and sanitization.
  	(req, res, next) => {
	  	// Extract the validation errors from a request.
	    const errors = validator.validationResult(req);

	    // Create a genre object with escaped and trimmed data.
		var options = {
		  	uri: 'http://localhost:3000/api/Deliver',
		  	method: 'POST',
		  	json:{
				"$class": "org.example.basic.Deliver",				
			  	"order": req.body.order,	
			  	"shipper": req.body.shipper
			}
		};

	    if (!errors.isEmpty()) {
	    	// There are errors. Render the form again with sanitized values/error messages.
	    	console.log("Error");
	    	console.log(errors);
	      	res.render('delivertransaction_form', { title: 'Create a Deliver Transaction', 
	      		errors: errors.array()});
	      	return;
	    } else {
	    	console.log("Success");
	    	request(options, function (error, response, body) {
			  if (!error && response.statusCode == 200) {
			    console.log(body) // Print the shortened url.
			    res.render('delivertransaction_form', { title: 'Create a Deliver Transaction',
			    	mess: 'Success!'});
			  } else {
			  	console.log(body['error']['message']);
	      		res.render('delivertransaction_form', { title: 'Create a Deliver Transaction', 
	      		mess: body['error']['message']});			  	
			  }
			});
	    }
	}
];

// Display Deliver Confirmation create form on GET.
exports.deliver_confirmation_transaction_get = function(req, res, next) {     
  res.render('deliver_confirmation_transaction_form', { title: 'Create a Deliver Confirmation Transaction' });
};

// Handle Deliver Confirmation create on POST.
exports.deliver_confirmation_transaction_post =  [
		
	// Validate that the siteForeMan field is not empty.
 	 validator.body('siteForeMan', 'Site Fore Man ID required').isLength({ min: 1 }).trim(),
	
	// Validate that the order field is not empty.
 	 validator.body('order', 'Order Number required').isLength({ min: 1 }).trim(),

  	// Sanitize (escape) the siteForeMan field.
  	validator.sanitizeBody('siteForeMan').escape(),

  	// Sanitize (escape) the order field.
  	validator.sanitizeBody('order').escape(),

  	// Process request after validation and sanitization.
  	(req, res, next) => {
	  	// Extract the validation errors from a request.
	    const errors = validator.validationResult(req);

	    // Create a genre object with escaped and trimmed data.
		var options = {
		  	uri: 'http://localhost:3000/api/DeliverConfirmation',
		  	method: 'POST',
		  	json:{
				"$class": "org.example.basic.DeliverConfirmation",				
			  	"order": req.body.order,	
			  	"siteForeMan": req.body.siteForeMan
			}
		};

	    if (!errors.isEmpty()) {
	    	// There are errors. Render the form again with sanitized values/error messages.
	    	console.log("Error");
	    	console.log(errors);
	      	res.render('deliver_confirmation_transaction_form', { title: 'Create a Deliver Confirmation Transaction', 
	      		errors: errors.array()});
	      	return;
	    } else {
	    	console.log("Success");
	    	request(options, function (error, response, body) {
			  if (!error && response.statusCode == 200) {
			    console.log(body) // Print the shortened url.
			    res.render('deliver_confirmation_transaction_form', { title: 'Create a Deliver Confirmation Transaction',
			    	mess: 'Success!'});
			  } else {
			  	console.log(body['error']['message']);
	      		res.render('deliver_confirmation_transaction_form', { title: 'Create a Deliver Confirmation Transaction', 
	      		mess: body['error']['message']});			  	
			  }
			});
	    }
	}
];


// Display Make Payment create form on GET.
exports.make_payment_transaction_get = function(req, res, next) {     
  res.render('make_payment_transaction_form', { title: 'Create a Make Payment Transaction' });
};

// Handle Make Payment create on POST.
exports.make_payment_transaction_post =  [
		
	// Validate that the commercialManager field is not empty.
 	 validator.body('commercialManager', 'Commercial Manager ID required').isLength({ min: 1 }).trim(),
	
	// Validate that the supplier field is not empty.
 	 validator.body('supplier', 'Supplier ID required').isLength({ min: 1 }).trim(),
	
	// Validate that the order field is not empty.
 	 validator.body('order', 'Order Number required').isLength({ min: 1 }).trim(),

	// Validate that the buyerBankAccount field is not empty.
 	 validator.body('buyerBankAccount', 'Bank Transaction Information required').isLength({ min: 1 }).trim(),

	// Validate that the paymentTransactionNumber field is not empty.
 	 validator.body('paymentTransactionNumber', 'Amount required').isLength({ min: 1 }).trim(),

  	// Sanitize (escape) the commercialManager field.
  	validator.sanitizeBody('commercialManager').escape(),

  	// Sanitize (escape) the supplier field.
  	validator.sanitizeBody('supplier').escape(),

  	// Sanitize (escape) the order field.
  	validator.sanitizeBody('order').escape(),

  	// Sanitize (escape) the buyerBankAccount field.
  	validator.sanitizeBody('buyerBankAccount').escape(),

  	// Sanitize (escape) the paymentTransactionNumber field.
  	validator.sanitizeBody('paymentTransactionNumber').escape(),

  	// Process request after validation and sanitization.
  	(req, res, next) => {
	  	// Extract the validation errors from a request.
	    const errors = validator.validationResult(req);

	    // Create a genre object with escaped and trimmed data.
		var options = {
		  	uri: 'http://localhost:3000/api/MakePayment',
		  	method: 'POST',
		  	json:{
				"$class": "org.example.basic.MakePayment",				
			  	"order": req.body.order,	
			  	"commercialManager": req.body.commercialManager,
			  	"buyerBankAccount": req.body.buyerBankAccount,
			  	"paymentTransactionNumber": req.body.paymentTransactionNumber,
			  	"supplier": req.body.supplier
			}
		};

	    if (!errors.isEmpty()) {
	    	// There are errors. Render the form again with sanitized values/error messages.
	    	console.log("Error");
	    	console.log(errors);
	      	res.render('make_payment_transaction_form', { title: 'Create a Make Payment Transaction', 
	      		errors: errors.array()});
	      	return;
	    } else {
	    	console.log("Success");
	    	request(options, function (error, response, body) {
			  if (!error && response.statusCode == 200) {
			    console.log(body) // Print the shortened url.
			    res.render('make_payment_transaction_form', { title: 'Create a Make Payment Transaction',
			    	mess: 'Success!'});
			  } else {
			  	console.log(body['error']['message']);
	      		res.render('make_payment_transaction_form', { title: 'Create a Make Payment Transaction', 
	      		mess: body['error']['message']});			  	
			  }
			});
	    }
	}
];

// Display Test Passed create form on GET.
exports.testpassed_transaction_get = function(req, res, next) {     
  res.render('test_passed_transaction_form', { title: 'Create a Test Passed Transaction' });
};

// Handle Test Passed create on POST.
exports.testpassed_transaction_post =  [
		
	// Validate that the installer field is not empty.
 	 validator.body('installer', 'Installer ID required').isLength({ min: 1 }).trim(),
	
	// Validate that the order field is not empty.
 	 validator.body('order', 'Order Number required').isLength({ min: 1 }).trim(),

  	// Sanitize (escape) the installer field.
  	validator.sanitizeBody('installer').escape(),

  	// Sanitize (escape) the order field.
  	validator.sanitizeBody('order').escape(),

  	// Process request after validation and sanitization.
  	(req, res, next) => {
	  	// Extract the validation errors from a request.
	    const errors = validator.validationResult(req);

	    // Create a genre object with escaped and trimmed data.
		var options = {
		  	uri: 'http://localhost:3000/api/TestPassed',
		  	method: 'POST',
		  	json:{
				"$class": "org.example.basic.TestPassed",				
			  	"order": req.body.order,	
			  	"installer": req.body.installer
			}
		};

	    if (!errors.isEmpty()) {
	    	// There are errors. Render the form again with sanitized values/error messages.
	    	console.log("Error");
	    	console.log(errors);
	      	res.render('test_passed_transaction_form', { title: 'Create a Test Passed Transaction', 
	      		errors: errors.array()});
	      	return;
	    } else {
	    	console.log("Success");
	    	request(options, function (error, response, body) {
			  if (!error && response.statusCode == 200) {
			    console.log(body) // Print the shortened url.
			    res.render('test_passed_transaction_form', { title: 'Create a Test Passed Transaction',
			    	mess: 'Success!'});
			  } else {
			  	console.log(body['error']['message']);
	      		res.render('test_passed_transaction_form', { title: 'Create a Test Passed Transaction', 
	      		mess: body['error']['message']});			  	
			  }
			});
	    }
	}
];

// Display Test Failed create form on GET.
exports.testfailed_transaction_get = function(req, res, next) {     
  res.render('test_failed_transaction_form', { title: 'Create a Test Failed Transaction' });
};

// Handle Test Failed create on POST.
exports.testfailed_transaction_post =  [
		
	// Validate that the installer field is not empty.
 	 validator.body('installer', 'Installer ID required').isLength({ min: 1 }).trim(),
	
	// Validate that the order field is not empty.
 	 validator.body('order', 'Order Number required').isLength({ min: 1 }).trim(),

	// Validate that the testComment field is not empty.
 	 validator.body('testComment', 'Test Comment required').isLength({ min: 1 }).trim(),

  	// Sanitize (escape) the installer field.
  	validator.sanitizeBody('installer').escape(),

  	// Sanitize (escape) the order field.
  	validator.sanitizeBody('order').escape(),

  	// Sanitize (escape) the testComment field.
  	validator.sanitizeBody('testComment').escape(),  	

  	// Process request after validation and sanitization.
  	(req, res, next) => {
	  	// Extract the validation errors from a request.
	    const errors = validator.validationResult(req);

	    // Create a genre object with escaped and trimmed data.
		var options = {
		  	uri: 'http://localhost:3000/api/TestFailed',
		  	method: 'POST',
		  	json:{
				"$class": "org.example.basic.TestFailed",				
			  	"order": req.body.order,	
			  	"testComment": req.body.testComment,
			  	"installer": req.body.installer
			}
		};

	    if (!errors.isEmpty()) {
	    	// There are errors. Render the form again with sanitized values/error messages.
	    	console.log("Error");
	    	console.log(errors);
	      	res.render('test_failed_transaction_form', { title: 'Create a Test Failed Transaction', 
	      		errors: errors.array()});
	      	return;
	    } else {
	    	console.log("Success");
	    	request(options, function (error, response, body) {
			  if (!error && response.statusCode == 200) {
			    console.log(body) // Print the shortened url.
			    res.render('test_failed_transaction_form', { title: 'Create a Test Failed Transaction',
			    	mess: 'Success!'});
			  } else {
			  	console.log(body['error']['message']);
	      		res.render('test_failed_transaction_form', { title: 'Create a Test Failed Transaction', 
	      		mess: body['error']['message']});			  	
			  }
			});
	    }
	}
];

// Display Not Installed create form on GET.
exports.notinstalled_transaction_get = function(req, res, next) {     
  res.render('notinstalled_transaction_form', { title: 'Create a Not Installed Transaction' });
};

// Handle Not Installed create on POST.
exports.notinstalled_transaction_post =  [
		
	// Validate that the clerkOfWork field is not empty.
 	 validator.body('clerkOfWork', 'Clerk Of Work ID required').isLength({ min: 1 }).trim(),
	
	// Validate that the order field is not empty.
 	 validator.body('order', 'Order Number required').isLength({ min: 1 }).trim(),

	// Validate that the installationComment field is not empty.
 	 validator.body('installationComment', 'Installation Comment required').isLength({ min: 1 }).trim(),

  	// Sanitize (escape) the clerkOfWork field.
  	validator.sanitizeBody('clerkOfWork').escape(),

  	// Sanitize (escape) the order field.
  	validator.sanitizeBody('order').escape(),

  	// Sanitize (escape) the installationComment field.
  	validator.sanitizeBody('installationComment').escape(),  	

  	// Process request after validation and sanitization.
  	(req, res, next) => {
	  	// Extract the validation errors from a request.
	    const errors = validator.validationResult(req);

	    // Create a genre object with escaped and trimmed data.
		var options = {
		  	uri: 'http://localhost:3000/api/NotInstalled',
		  	method: 'POST',
		  	json:{
				"$class": "org.example.basic.NotInstalled",				
			  	"order": req.body.order,	
			  	"installationComment": req.body.installationComment,
			  	"clerkOfWork": req.body.clerkOfWork
			}
		};

	    if (!errors.isEmpty()) {
	    	// There are errors. Render the form again with sanitized values/error messages.
	    	console.log("Error");
	    	console.log(errors);
	      	res.render('notinstalled_transaction_form', { title: 'Create a Not Installed Transaction', 
	      		errors: errors.array()});
	      	return;
	    } else {
	    	console.log("Success");
	    	request(options, function (error, response, body) {
			  if (!error && response.statusCode == 200) {
			    console.log(body) // Print the shortened url.
			    res.render('notinstalled_transaction_form', { title: 'Create a Not Installed Transaction',
			    	mess: 'Success!'});
			  } else {
			  	console.log(body['error']['message']);
	      		res.render('notinstalled_transaction_form', { title: 'Create a Not Installed Transaction', 
	      		mess: body['error']['message']});			  	
			  }
			});
	    }
	}
];

// Display Installed create form on GET.
exports.installed_transaction_get = function(req, res, next) {     
  res.render('installed_transaction_form', { title: 'Create a Installed Transaction' });
};

// Handle Installed create on POST.
exports.installed_transaction_post =  [
		
	// Validate that the clerkOfWork field is not empty.
 	 validator.body('clerkOfWork', 'Clerk Of Work ID required').isLength({ min: 1 }).trim(),
	
	// Validate that the order field is not empty.
 	 validator.body('order', 'Order Number required').isLength({ min: 1 }).trim(),

	// Validate that the installationComment field is not empty.
 	 validator.body('installationComment', 'Installation Comment required').isLength({ min: 1 }).trim(),

  	// Sanitize (escape) the clerkOfWork field.
  	validator.sanitizeBody('clerkOfWork').escape(),

  	// Sanitize (escape) the order field.
  	validator.sanitizeBody('order').escape(),

  	// Sanitize (escape) the installationComment field.
  	validator.sanitizeBody('installationComment').escape(),  	

  	// Process request after validation and sanitization.
  	(req, res, next) => {
	  	// Extract the validation errors from a request.
	    const errors = validator.validationResult(req);

	    // Create a genre object with escaped and trimmed data.
		var options = {
		  	uri: 'http://localhost:3000/api/Installed',
		  	method: 'POST',
		  	json:{
				"$class": "org.example.basic.Installed",				
			  	"order": req.body.order,	
			  	"installationComment": req.body.installationComment,
			  	"clerkOfWork": req.body.clerkOfWork
			}
		};

	    if (!errors.isEmpty()) {
	    	// There are errors. Render the form again with sanitized values/error messages.
	    	console.log("Error");
	    	console.log(errors);
	      	res.render('installed_transaction_form', { title: 'Create a Installed Transaction', 
	      		errors: errors.array()});
	      	return;
	    } else {
	    	console.log("Success");
	    	request(options, function (error, response, body) {
			  if (!error && response.statusCode == 200) {
			    console.log(body) // Print the shortened url.
			    res.render('installed_transaction_form', { title: 'Create a Installed Transaction',
			    	mess: 'Success!'});
			  } else {
			  	console.log(body['error']['message']);
	      		res.render('installed_transaction_form', { title: 'Create a Installed Transaction', 
	      		mess: body['error']['message']});			  	
			  }
			});
	    }
	}
];

// Display Test and Install Confirmation create form on GET.
exports.test_and_install_confirmation_transaction_get = function(req, res, next) {     
  res.render('test_and_install_confirmation_transaction_form', { title: 'Create a Test and Install Confirmation Transaction' });
};

// Handle Test and Install Confirmation create on POST.
exports.test_and_install_confirmation_transaction_post =  [
		
	// Validate that the order field is not empty.
 	 validator.body('order', 'Order Number required').isLength({ min: 1 }).trim(),

  	// Sanitize (escape) the order field.
  	validator.sanitizeBody('order').escape(),

  	// Process request after validation and sanitization.
  	(req, res, next) => {
	  	// Extract the validation errors from a request.
	    const errors = validator.validationResult(req);

	    // Create a genre object with escaped and trimmed data.
		var options = {
		  	uri: 'http://localhost:3000/api/TestAndInstallationConfirmation',
		  	method: 'POST',
		  	json:{
				"$class": "org.example.basic.TestAndInstallationConfirmation",				
			  	"order": req.body.order	
			}
		};

	    if (!errors.isEmpty()) {
	    	// There are errors. Render the form again with sanitized values/error messages.
	    	console.log("Error");
	    	console.log(errors);
	      	res.render('test_and_install_confirmation_transaction_form', { title: 'Create a Test and Install Confirmation Transaction', 
	      		errors: errors.array()});
	      	return;
	    } else {
	    	console.log("Success");
	    	request(options, function (error, response, body) {
			  if (!error && response.statusCode == 200) {
			    console.log(body) // Print the shortened url.
			    res.render('test_and_install_confirmation_transaction_form', { title: 'Create a Test and Install Confirmation Transaction',
			    	mess: 'Success!'});
			  } else {
			  	console.log(body['error']['message']);
	      		res.render('test_and_install_confirmation_transaction_form', { title: 'Create a Test and Install Confirmation Transaction', 
	      		mess: body['error']['message']});			  	
			  }
			});
	    }
	}
];


// Display Request Refund create form on GET.
exports.request_refund_transaction_get = function(req, res, next) {     
  res.render('request_refund_transaction_form', { title: 'Create a Request Refund Transaction' });
};

// Handle Request Refund create on POST.
exports.request_refund_transaction_post =  [
		
	// Validate that the order field is not empty.
 	 validator.body('order', 'Order Number required').isLength({ min: 1 }).trim(),

  	// Sanitize (escape) the order field.
  	validator.sanitizeBody('order').escape(),

  	// Process request after validation and sanitization.
  	(req, res, next) => {
	  	// Extract the validation errors from a request.
	    const errors = validator.validationResult(req);

	    // Create a genre object with escaped and trimmed data.
		var options = {
		  	uri: 'http://localhost:3000/api/RequestRefund',
		  	method: 'POST',
		  	json:{
				"$class": "org.example.basic.RequestRefund",				
			  	"order": req.body.order	
			}
		};

	    if (!errors.isEmpty()) {
	    	// There are errors. Render the form again with sanitized values/error messages.
	    	console.log("Error");
	    	console.log(errors);
	      	res.render('request_refund_transaction_form', { title: 'Create a Request Refund Transaction', 
	      		errors: errors.array()});
	      	return;
	    } else {
	    	console.log("Success");
	    	request(options, function (error, response, body) {
			  if (!error && response.statusCode == 200) {
			    console.log(body) // Print the shortened url.
			    res.render('request_refund_transaction_form', { title: 'Create a Request Refund Transaction',
			    	mess: 'Success!'});
			  } else {
			  	console.log(body['error']['message']);
	      		res.render('request_refund_transaction_form', { title: 'Create a Request Refund Transaction', 
	      		mess: body['error']['message']});			  	
			  }
			});
	    }
	}
];

// Display Request Shipping Back create form on GET.
exports.request_shipping_back_transaction_get = function(req, res, next) {     
  res.render('request_shipping_back_transaction_form', { title: 'Create a Request Shipping Back Transaction' });
};

// Handle Request Shipping Back create on POST.
exports.request_shipping_back_transaction_post =  [
		
	// Validate that the siteForeMan field is not empty.
 	 validator.body('siteForeMan', 'Site Fore Man ID required').isLength({ min: 1 }).trim(),
	
	// Validate that the supplier field is not empty.
 	 validator.body('supplier', 'Supplier ID required').isLength({ min: 1 }).trim(),

	// Validate that the order field is not empty.
 	 validator.body('order', 'Order Number required').isLength({ min: 1 }).trim(),


  	// Sanitize (escape) the siteForeMan field.
  	validator.sanitizeBody('siteForeMan').escape(),

  	// Sanitize (escape) the supplier field.
  	validator.sanitizeBody('supplier').escape(),

  	// Sanitize (escape) the order field.
  	validator.sanitizeBody('order').escape(),

  	// Process request after validation and sanitization.
  	(req, res, next) => {
	  	// Extract the validation errors from a request.
	    const errors = validator.validationResult(req);

	    // Create a genre object with escaped and trimmed data.
		var options = {
		  	uri: 'http://localhost:3000/api/RequestShippingBackOrder',
		  	method: 'POST',
		  	json:{
				"$class": "org.example.basic.RequestShippingBackOrder",	
				"siteForeMan": req.body.siteForeMan,
				"supplier": req.body.supplier,			
			  	"order": req.body.order
			}
		};

	    if (!errors.isEmpty()) {
	    	// There are errors. Render the form again with sanitized values/error messages.
	    	console.log("Error");
	    	console.log(errors);
	      	res.render('request_shipping_back_transaction_form', { title: 'Create a Request Shipping Back Transaction', 
	      		errors: errors.array()});
	      	return;
	    } else {
	    	console.log("Success");
	    	request(options, function (error, response, body) {
			  if (!error && response.statusCode == 200) {
			    console.log(body) // Print the shortened url.
			    res.render('request_shipping_back_transaction_form', { title: 'Create a Request Shipping Back Transaction',
			    	mess: 'Success!'});
			  } else {
			  	console.log(body['error']['message']);
	      		res.render('request_shipping_back_transaction_form', { title: 'Create a Request Shipping Back Transaction', 
	      		mess: body['error']['message']});			  	
			  }
			});
	    }
	}
];


// Display Refund create form on GET.
exports.refund_transaction_get = function(req, res, next) {     
  res.render('refund_transaction_form', { title: 'Create a Refund Transaction' });
};

// Handle Refund create on POST.
exports.refund_transaction_post =  [
		
	// Validate that the order field is not empty.
 	 validator.body('order', 'Order Number required').isLength({ min: 1 }).trim(),

	// Validate that the refundTransactionNumber field is not empty.
 	 validator.body('refundTransactionNumber', 'Refund Transaction Information required').isLength({ min: 1 }).trim(),

  	// Sanitize (escape) the order field.
  	validator.sanitizeBody('order').escape(),

  	// Sanitize (escape) the buyerBankAccount field.
  	validator.sanitizeBody('refundTransactionNumber').escape(),

  	// Process request after validation and sanitization.
  	(req, res, next) => {
	  	// Extract the validation errors from a request.
	    const errors = validator.validationResult(req);

	    // Create a genre object with escaped and trimmed data.
		var options = {
		  	uri: 'http://localhost:3000/api/Refund',
		  	method: 'POST',
		  	json:{
				"$class": "org.example.basic.Refund",				
			  	"order": req.body.order,	
			  	"refundTransactionNumber": req.body.refundTransactionNumber
			}
		};

	    if (!errors.isEmpty()) {
	    	// There are errors. Render the form again with sanitized values/error messages.
	    	console.log("Error");
	    	console.log(errors);
	      	res.render('refund_transaction_form', { title: 'Create a Refund Transaction', 
	      		errors: errors.array()});
	      	return;
	    } else {
	    	console.log("Success");
	    	request(options, function (error, response, body) {
			  if (!error && response.statusCode == 200) {
			    console.log(body) // Print the shortened url.
			    res.render('refund_transaction_form', { title: 'Create a Refund Transaction',
			    	mess: 'Success!'});
			  } else {
			  	console.log(body['error']['message']);
	      		res.render('refund_transaction_form', { title: 'Create a Refund Transaction', 
	      		mess: body['error']['message']});			  	
			  }
			});
	    }
	}
];


// Display Order Completed create form on GET.
exports.order_completed_transaction_get = function(req, res, next) {     
  res.render('order_completed_transaction_form', { title: 'Create a Order Completed Transaction' });
};

// Handle Order Completed create on POST.
exports.order_completed_transaction_post =  [
		
	// Validate that the order field is not empty.
 	 validator.body('order', 'Order Number required').isLength({ min: 1 }).trim(),

  	// Sanitize (escape) the order field.
  	validator.sanitizeBody('order').escape(),

  	// Process request after validation and sanitization.
  	(req, res, next) => {
	  	// Extract the validation errors from a request.
	    const errors = validator.validationResult(req);

	    // Create a genre object with escaped and trimmed data.
		var options = {
		  	uri: 'http://localhost:3000/api/OrderCompleted',
		  	method: 'POST',
		  	json:{
				"$class": "org.example.basic.OrderCompleted",				
			  	"order": req.body.order
			}
		};

	    if (!errors.isEmpty()) {
	    	// There are errors. Render the form again with sanitized values/error messages.
	    	console.log("Error");
	    	console.log(errors);
	      	res.render('order_completed_transaction_form', { title: 'Create a Order Completed Transaction', 
	      		errors: errors.array()});
	      	return;
	    } else {
	    	console.log("Success");
	    	request(options, function (error, response, body) {
			  if (!error && response.statusCode == 200) {
			    console.log(body) // Print the shortened url.
			    res.render('order_completed_transaction_form', { title: 'Create a Order Completed Transaction',
			    	mess: 'Success!'});
			  } else {
			  	console.log(body['error']['message']);
	      		res.render('order_completed_transaction_form', { title: 'Create a Order Completed Transaction', 
	      		mess: body['error']['message']});			  	
			  }
			});
	    }
	}
];